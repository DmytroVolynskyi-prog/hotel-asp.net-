﻿using Microsoft.AspNetCore.Mvc;
using HotelManagement.Models;
using System;
using System.Collections.Generic;

namespace HotelManagement.Controllers
{
    public class roomsAdminController : Controller
    {
        Database db = new Database();

        public IActionResult Index(string searchTerm)
        {
            List<Rooms> rooms;
            if (!string.IsNullOrEmpty(searchTerm))
            {
                rooms = db.GetRooms(searchTerm);
            }
            else
            {
                rooms = db.GetRooms();
            }
            ViewBag.SearchTerm = searchTerm;
            return View(rooms);
        }
		public IActionResult Delete1(string room_number)
		{
			try
			{
				bool isDeleted = db.DeleteRooms(room_number);
				if (isDeleted)
				{
					return RedirectToAction("Index");
				}
				else
				{
					ModelState.AddModelError("", "Failed to delete reservation.");
					return View("Index");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine($"An error occurred: {ex.Message}");
				ModelState.AddModelError("", "An error occurred while deleting reservation.");
				return View("Index");
			}
		}
	}
}