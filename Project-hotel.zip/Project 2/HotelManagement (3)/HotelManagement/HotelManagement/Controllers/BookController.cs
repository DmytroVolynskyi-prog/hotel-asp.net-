﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HotelManagement.Models;
using HotelManagement;
namespace HotelManagement.Controllers
{
	public class BookController : Controller
	{
		Database db = new Database();

		public IActionResult Index()
		{
			return View();
		}


		[HttpPost]
		public IActionResult Check(Book book)
		{
			if (ModelState.IsValid)
			{
				try
				{
					bool isAuthenticated = db.RegisterRoom(book.first_name, book.last_name, book.phone, book.room_number, book.check_in_date, book.check_out_date);
					if (isAuthenticated)
					{
						return View("Success");
					}
					else
					{
						ModelState.AddModelError("", "Authentication failed");
						return View("Failure");
					}
				}
				catch (Exception ex)
				{
					// Логирование ошибки
					Console.WriteLine($"An error occurred: {ex.Message}");
					return View("Failure");
				}
			}
			return View("Index"); // Явно указываем представление, которое должно быть возвращено
		}

		[HttpPost]
		public IActionResult Insert(Login login)
		{
			if (ModelState.IsValid)
			{
				try
				{
					db.InsertUser(login.Name, login.Surname, login.Password);
					return View("Profile");
				}
				catch (Exception ex)
				{
					// Логирование ошибки
					Console.WriteLine($"An error occurred: {ex.Message}");
					return View("Failure");
				}
			}
			return View();
		}
	}

}


