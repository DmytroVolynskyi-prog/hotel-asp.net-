﻿using Microsoft.AspNetCore.Mvc;
using HotelManagement.Models;
using System;
using System.Collections.Generic;

namespace HotelManagement.Controllers
{
    public class undermaintenceController : Controller
    {
        Database db = new Database();

        public IActionResult Index(string searchTerm)
        {
            List<undermaintence> Undermaintence;
            if (!string.IsNullOrEmpty(searchTerm))
            {
                Undermaintence = db.GetRooms1(searchTerm);
            }
            else
            {
                Undermaintence = db.GetRooms1();
            }
            ViewBag.SearchTerm = searchTerm;
            return View(Undermaintence);
        }
    }
}