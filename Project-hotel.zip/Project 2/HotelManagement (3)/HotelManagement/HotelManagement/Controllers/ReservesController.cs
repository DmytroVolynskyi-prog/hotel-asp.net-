﻿using Microsoft.AspNetCore.Mvc;
using System;
using HotelManagement.Models;
using HotelManagement;

namespace HotelManagement.Controllers
{
    public class ReservesController : Controller
    {
        Database db = new Database();

        public IActionResult Index(string searchTerm)
        {
            var books = string.IsNullOrEmpty(searchTerm) ? db.GetReserves() : db.GetReserves(searchTerm);
            ViewBag.SearchTerm = searchTerm;
            return View(books);
        }

        [HttpPost]
        public IActionResult Delete(string first_name)
        {
            try
            {
                bool isDeleted = db.DeleteReserves(first_name);
                if (isDeleted)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "Failed to delete reservation.");
                    return View("Index");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                ModelState.AddModelError("", "An error occurred while deleting reservation.");
                return View("Index");
            }
        }
    }
}