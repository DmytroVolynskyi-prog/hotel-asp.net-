﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HotelManagement.Models;
using HotelManagement;
namespace HotelManagement.Controllers
{
    public class LoginController : Controller
    {
        Database db = new Database();

        public IActionResult Index()
        {
            return View();
        }

        
        [HttpPost]
        public IActionResult Check(Login login)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    bool isAuthenticated = db.AuthenticateUser(login.Name, login.Surname, login.Password);
                    if (isAuthenticated)
                    {
                        return View("Profile");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Authentication failed");
                        return View("Failure");
                    }
                }
                catch (Exception ex)
                {
                    // Логирование ошибки
                    Console.WriteLine($"An error occurred: {ex.Message}");
                    return View("Failure");
                }
            }
            return View("Index"); // Явно указываем представление, которое должно быть возвращено
        }

        [HttpPost]
        public IActionResult Insert(Login login)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    db.InsertUser(login.Name, login.Surname, login.Password);
                    return View("Profile");
                }
                catch (Exception ex)
                {
                    // Логирование ошибки
                    Console.WriteLine($"An error occurred: {ex.Message}");
                    return View("Failure");
                }
            }
            return View();
        }
    }

}


