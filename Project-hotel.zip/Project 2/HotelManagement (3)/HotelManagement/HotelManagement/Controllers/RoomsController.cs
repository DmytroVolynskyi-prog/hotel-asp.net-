﻿using Microsoft.AspNetCore.Mvc;
using HotelManagement.Models;
using System;
using System.Collections.Generic;

namespace HotelManagement.Controllers
{
    public class RoomsController : Controller
    {
        Database db = new Database();

        public IActionResult Index(string searchTerm)
        {
            List<Rooms> rooms;
            if (!string.IsNullOrEmpty(searchTerm))
            {
                rooms = db.GetRooms(searchTerm);
            }
            else
            {
                rooms = db.GetRooms();
            }
            ViewBag.SearchTerm = searchTerm;
            return View(rooms);
        }
    }
}