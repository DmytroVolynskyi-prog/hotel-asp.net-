﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HotelManagement.Models
{
    public class Book
    {
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(20, ErrorMessage = "Name cannot be longer than 20 characters.")]
        public string first_name { get; set; }

        [Required(ErrorMessage = "Surname is required.")]
        [StringLength(30, ErrorMessage = "The surname cannot be longer than 30 characters.")]
        public string last_name { get; set; }

        [Required(ErrorMessage = "Telefon is required.")]
        [RegularExpression(@"^[0-9]{9}$", ErrorMessage = "The phone number must have 9 digits.")]
        public string phone { get; set; }

        
        public string room_number { get; set; }

        [Required(ErrorMessage = "Arrival date is required.")]
        [DataType(DataType.Date)]
        public DateTime check_in_date { get; set; }

        [Required(ErrorMessage = "Departure date is required.")]
        [DataType(DataType.Date)]
        public DateTime check_out_date { get; set; }
    }
}