﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using HotelManagement.Models;


namespace HotelManagement
{
    public class Database
    {
        SqlConnection status = new SqlConnection(@"Server=localhost;Database=HotelManagement;Trusted_Connection=true");

        public void connectDB()
        {
            if (status.State == System.Data.ConnectionState.Closed)
            {
                status.Open();
            }
        }
        public void disconnectDB()
        {
            if (status.State == System.Data.ConnectionState.Open)
            {
                status.Close();
            }
        }
        public SqlConnection show()
        {
            return status;
        }

       

       
    
        //public class HotelContext : DbContext
        //{
        //    public HotelContext(DbContextOptions<HotelContext> options) : base(options) { }

        //    public DbSet<HotelManagement.Models.Room> Rooms { get; set; }
        //}
    

 
		public bool AuthenticateUser(string Name, string Surname, string Password)
        {
            bool isAuthenticated = false;
            if (status.State != System.Data.ConnectionState.Open)
            {
                connectDB();
            }

            try
            {
                string query = "SELECT COUNT(*) FROM Logowanie WHERE Name = @Name AND Surname=@Surname AND Password = @Password";
                SqlCommand command = new SqlCommand(query, status);
                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Surname", Surname);
                command.Parameters.AddWithValue("@Password", Password);

                if (status.State != System.Data.ConnectionState.Open)
                {
                    status.Open();
                }

                int count = (int)command.ExecuteScalar();

                isAuthenticated = (count > 0);

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Service error: {ex}");
            }
            finally
            {
                status.Close();
            }
            disconnectDB();
            return isAuthenticated;
        }

        public void InsertUser(string Name, string Surname, string Password)
        {
            if (status.State != System.Data.ConnectionState.Open)
            {
                connectDB();
            }

            try
            {
                string query = "INSERT INTO Login (Name, Surname, Password) VALUES (@Name, @Surname, @Password)";
                SqlCommand command = new SqlCommand(query, status);
                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Surname", Surname);
                command.Parameters.AddWithValue("@Password", Password);

                if (status.State != System.Data.ConnectionState.Open)
                {
                    connectDB();
                }

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Service error: {ex}");
            }
            finally
            {
                status.Close();
            }
            disconnectDB();
        }

        public List<Rooms> GetRooms(string searchTerm = null)
        {
            List<Rooms> rooms = new List<Rooms>();

            if (status.State != ConnectionState.Open)
            {
                connectDB();
            }

            string query = "SELECT room_number, description, price, image_path,condition FROM hotel_rooms";
            if (!string.IsNullOrEmpty(searchTerm))
            {
                query += " WHERE description LIKE @searchTerm";
            }
            SqlCommand command = new SqlCommand(query, status);

            if (!string.IsNullOrEmpty(searchTerm))
            {
                command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
            }

            try
            {
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Rooms room = new Rooms
                    {
                        room_number = reader["room_number"].ToString(),
                        description = reader["description"].ToString(),
                        price = reader["price"].ToString(),
                        image_path = reader["image_path"].ToString(),
                        condition = reader["condition"].ToString()
                    };
                    rooms.Add(room);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                disconnectDB();
            }

            return rooms;
        }

        public List<undermaintence> GetRooms1(string searchTerm = null)
        {
            List<undermaintence> Undermaintence = new List<undermaintence>();

            if (status.State != ConnectionState.Open)
            {
                connectDB();
            }

            string query = "SELECT room_number, description, price, image_path,condition FROM hotel_rooms WHERE room_number='107' OR room_number='108'";

            if (!string.IsNullOrEmpty(searchTerm))
            {
                query += " WHERE description LIKE @searchTerm";
            }
            SqlCommand command = new SqlCommand(query, status);

            if (!string.IsNullOrEmpty(searchTerm))
            {
                command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
            }

            try
            {
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    undermaintence Undermaintenc = new undermaintence
                    {
                        room_number = reader["room_number"].ToString(),
                        description = reader["description"].ToString(),
                        price = reader["price"].ToString(),
                        image_path = reader["image_path"].ToString(),
                        condition = reader["condition"].ToString()
                    };
                    Undermaintence.Add(Undermaintenc);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                disconnectDB();
            }

            return Undermaintence;
        }
		public bool RegisterRoom(string first_name, string last_name, string phone, string room_number, DateTime check_in_date, DateTime check_out_date)
		{
			bool isRegistered = false;
			if (status.State != System.Data.ConnectionState.Open)
			{
				connectDB();
			}

			try
			{
				string query = "INSERT INTO BookForm (first_name, last_name, phone, room_number, check_in_date,check_out_date ) VALUES (@first_name, @last_name, @phone, @room_number, @check_in_date,@check_out_date)";
				SqlCommand command = new SqlCommand(query, status);
				command.Parameters.AddWithValue("@first_name", first_name);
				command.Parameters.AddWithValue("@last_name", last_name);
				command.Parameters.AddWithValue("@phone", phone);
				command.Parameters.AddWithValue("@room_number", room_number);
				command.Parameters.AddWithValue("@check_in_date", check_in_date);
				command.Parameters.AddWithValue("@check_out_date", check_out_date);

				if (status.State != System.Data.ConnectionState.Open)
				{
					status.Open();
				}

				int rowsAffected = command.ExecuteNonQuery();

				isRegistered = (rowsAffected > 0);
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Service error: {ex}");
			}
			finally
			{
				status.Close();
			}
			disconnectDB();
			return isRegistered;
		}
		public List<Book> GetReserves(string searchTerm = null)
		{
			List<Book> book = new List<Book>();

			if (status.State != ConnectionState.Open)
			{
				connectDB();
			}

			string query = "SELECT first_name, last_name, phone, room_number, email,check_in_date,check_out_date FROM BookForm";
			if (!string.IsNullOrEmpty(searchTerm))
			{
				query += " WHERE description LIKE @searchTerm";
			}
			SqlCommand command = new SqlCommand(query, status);

			if (!string.IsNullOrEmpty(searchTerm))
			{
				command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
			}

			try
			{
				SqlDataReader reader = command.ExecuteReader();

				while (reader.Read())
				{
					Book books = new Book
					{
						first_name = reader["first_name"].ToString(),
						last_name = reader["last_name"].ToString(),
						phone = reader["phone"].ToString(),
                        room_number = reader["room_number"].ToString(),
                        check_in_date = reader.GetDateTime(reader.GetOrdinal("check_in_date")),
						check_out_date = reader.GetDateTime(reader.GetOrdinal("check_out_date"))
					};
					book.Add(books);
				}
				reader.Close();
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Error: {ex.Message}");
			}
			finally
			{
				disconnectDB();
			}

			return book;
		}
		public bool ReservesRoom(string first_name, string last_name, string phone, string room_number, DateTime check_in_date, DateTime check_out_date)
		{
			bool isRegistered = false;
			if (status.State != System.Data.ConnectionState.Open)
			{
				connectDB();
			}

			try
			{
				string query = "Select INTO BookForm (first_name, last_name, phone, room_number, check_in_date,check_out_date) VALUES (@first_name, @last_name, @phone, @room_number, @check_in_date,@check_out_date)";
				SqlCommand command = new SqlCommand(query, status);
				command.Parameters.AddWithValue("@first_name", first_name);
				command.Parameters.AddWithValue("@last_name", last_name);
				command.Parameters.AddWithValue("@phone", phone);
                command.Parameters.AddWithValue("@room_number", room_number);
                command.Parameters.AddWithValue("@check_in_date", check_in_date);
				command.Parameters.AddWithValue("@check_out_date", check_out_date);

				if (status.State != System.Data.ConnectionState.Open)
				{
					status.Open();
				}

				int rowsAffected = command.ExecuteNonQuery();

				isRegistered = (rowsAffected > 0);
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Service error: {ex}");
			}
			finally
			{
				status.Close();
			}
			disconnectDB();
			return isRegistered;
		}
        public bool DeleteReserves(string first_name)
        {
            bool isDeleted = false;

            if (status.State != System.Data.ConnectionState.Open)
            {
                connectDB();
            }

            try
            {
                string query = "DELETE FROM BookForm WHERE first_name = @first_name";
                SqlCommand command = new SqlCommand(query, status);
                command.Parameters.AddWithValue("@first_name", first_name);

                if (status.State != System.Data.ConnectionState.Open)
                {
                    status.Open();
                }

                int rowsAffected = command.ExecuteNonQuery();

                isDeleted = (rowsAffected > 0);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Service error: {ex}");
            }
            finally
            {
                status.Close();
            }

            disconnectDB();
            return isDeleted;
        }
		public bool DeleteRooms(string room_number)
		{
			bool isDeleted = false;

			if (status.State != System.Data.ConnectionState.Open)
			{
				connectDB();
			}

			try
			{
				string query = "DELETE FROM hotel_rooms WHERE room_number = @room_number";
				SqlCommand command = new SqlCommand(query, status);
				command.Parameters.AddWithValue("@room_number", room_number);

				if (status.State != System.Data.ConnectionState.Open)
				{
					status.Open();
				}

				int rowsAffected = command.ExecuteNonQuery();

				isDeleted = (rowsAffected > 0);
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Service error: {ex}");
			}
			finally
			{
				status.Close();
			}

			disconnectDB();
			return isDeleted;
		}
	
}
}


